#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int a(int a);
int b(int b);
int c(int c);

int a(int a) {
	printf("a=%d\n", a);
	return b(a + 4);
}

int b(int b) {
	printf("b=%d\n", b);
	return c(b * 2);
}

int c(int c) {
	printf("c=%d\n", c);
	return a(c * 3 + 5);
}

int main(void) {
	return a(2);
}
