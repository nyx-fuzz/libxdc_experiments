#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(void) {
	//sleep(2);
	int x = 1;
	for (int i = 0; i < 1000; i++) {
		if (x % 2 == 0) {
			printf("A\n");
			x += 1;
		} else if (x % 3 == 0) {
			printf("B\n");
			x += 7;
		} else {
			printf("C\n");
			x *= 5;
		}
	}

	printf("i = %d\n", x);
}
